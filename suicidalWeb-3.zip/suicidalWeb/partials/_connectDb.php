<?php
// $login = false;
// $showError = false;
// $servername = "localhost";
// $username ="root";
// $password ="";
// $database ="suicidaldb";

// $conn = mysqli_connect($servername,$username,$password,$database);
// if (!$conn){
//   die("Sorry we Failed to Connect:". mysqli_connect_error());
// }
// else{
// }
// if($_SERVER["REQUEST_METHOD"] == "POST")
// {
//   $password = $_POST["password"];
//   $sql ="Select * from admin where password='$password'";
//   $result = mysqli_query($conn,$sql);
//   $num = mysqli_num_rows($result);
// if ($password == "Smart44Byte" || $password == "Arkam"){
//     header("Location: icon.ico");
//   }}
define("DB_SERVER", "localhost");
define("DB_USERNAME", "root");
define("DB_PASSWORD", "");
define("DB_NAME", "suicidalWeb");

# Connection
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

# Check connection
if (!$link) {
  die("Connection failed: " . mysqli_connect_error());
}
?>