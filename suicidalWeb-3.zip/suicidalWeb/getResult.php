<?php
include("partials/_connectDb.php");
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $newSub = $_POST["newSub"];
    if ($newSub) {
  
      $question = array($_POST['getResponse']);
      $sql = "SELECT * FROM olddata";
      $result = mysqli_query($conn,$sql);
      if($result){
        foreach($row as mysqli_fetch_assoc($result)){

        }
      }
      
    }
  }

  
?>