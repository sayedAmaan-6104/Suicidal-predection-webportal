<?php
// navbar
include("partials/navbar.php")
?>
<div class="container-xxl py-5 bg-primary hero-header mb-5">
                <div class="container my-5 py-5 px-lg-5">
                    <div class="row g-5 py-5">
                        <div class="col-12 text-center">
                            <h1 class="text-white animated zoomIn">Contact Us</h1>
                            <hr class="bg-white mx-auto mt-0" style="width: 90px;">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb justify-content-center">
                                    <li class="breadcrumb-item"><a class="text-white" href="#">Home</a></li>
                                    <li class="breadcrumb-item"><a class="text-white" href="#">Pages</a></li>
                                    <li class="breadcrumb-item text-white active" aria-current="page">Contact</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- <br><br><br><br><br>  -->
<!-- form tabs start -->
<div id="wrapper">
        <div id="tabContainer">
            <div id="tabs">
                <ul>
                    <li id="tabHeader_1">Depression</li>
                    <li id="tabHeader_2">Relationship</li>
                    <li id="tabHeader_3">Money</li>
                    <li id="tabHeader_4">Education</li>
                </ul>
            </div>
            <div id="tabscontent">
                <div class="tabpage" id="tabpage_1">
                    <!-- Tab1 -->
                    <!-- Form1 start -->
                    <form id="form">
                        <h3>Fill if you feel like you are depressed</h3>
                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>
                        

                        <!-- Multi-line Text Input Control -->
                        <button type="submit" value="value1">
                            Submit
                        </button>
                    </form>
                    <!-- form1 end -->
                </div>

                <div class="tabpage hidden" id="tabpage_2">
                    <!-- Tab1 -->
                    <!-- Form1 start -->
                    <form id="form">
                    <h3>Fill if you feel like you have Relationship problem</h3>
                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>
                        

                        <!-- Multi-line Text Input Control -->
                        <button type="submit" value="value1">
                            Submit
                        </button>
                    </form>
                    <!-- form1 end -->
                </div>

                <div class="tabpage hidden" id="tabpage_3">
                    <!-- Tab1 -->
                    <!-- Form1 start -->
                    <form id="form">
                    <h3>Fill if you feel have money problems</h3>
                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>
                        

                        <!-- Multi-line Text Input Control -->
                        <button type="submit" value="value1">
                            Submit
                        </button>
                    </form>
                    <!-- form1 end -->
                </div>
                
                <div class="tabpage hidden" id="tabpage_4">
                    <!-- Tab1 -->
                    <!-- Form1 start -->
                    <form id="form">
                    <h3>Fill if you feel have education problem</h3>
                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>

                        <!-- Question1 -->
                        <div class="form-control">
                            <label>
                                => Do you feel falling of the building?
                            </label>
                            <!-- Input Type Radio Button -->
                            <label for="recommed-1">
                                <input type="radio" id="recommed-1" name="recommed">Everytime</input>
                            </label>
                            <label for="recommed-2">
                                <input type="radio" id="recommed-2" name="recommed">Sometime</input>
                            </label>
                            <label for="recommed-3">
                                <input type="radio" id="recommed-3" name="recommed">Never</input>
                            </label>
                        </div>
                        

                        <!-- Multi-line Text Input Control -->
                        <button type="submit" value="value1">
                            Submit
                        </button>
                    </form>
                    <!-- form1 end -->
                </div>
                
                
            </div>
        </div>
    </div>
<!-- form tab end -->
<?php
// footer
include("partials/footer.php")
?>