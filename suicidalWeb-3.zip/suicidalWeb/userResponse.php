<?php
include("partials/navbar.php");
include("partials/_connectDb.php");
?>
<div class="container-xxl py-5 bg-primary hero-header mb-5">
    <div class="container my-5 py-5 px-lg-5">
        <div class="row g-5 py-5">
            <div class="col-12 text-center">
                <h1 class="text-white animated zoomIn">View Response</h1>
                <hr class="bg-white mx-auto mt-0" style="width: 90px;">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb justify-content-center">
                        <li class="breadcrumb-item"><a class="text-white" href="#">Home</a></li>
                        <li class="breadcrumb-item"><a class="text-white" href="#">View Response</a></li>
                        <li class="breadcrumb-item text-white active" aria-current="page">Contact</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>
</div><!-- <br><br><br><br><br>  -->

<!--  Response table start-->
<table id="MyTable" class="display" cellspacing="0" width="100%">
    <thead>
        <tr>
            <?php
            if ($_SESSION['role'] == 1) {
            ?>
                <td>Username</td>
            <?php
            }
            ?>
            <th>Form Name</th>
            <th>Percent</th>
            <th>SubmitDate</th>
            <th>Suicide</th>

        </tr>
    </thead>
    <tfoot>
        <tr>
        <?php
            if ($_SESSION['role'] == 1) {
            ?>
                <td>Username</td>
            <?php
            }
            ?>
            <th>Form Name</th>
            <th>Percent</th>
            <th>SubmitDate</th>
            <th>Suicide</th>

        </tr>
    </tfoot>
    <tbody>
        <?php
        if ($_SESSION['role'] == 1) {
            // Define the SQL query
            $sql = "SELECT * FROM `user_response`";
        } else {
            $username = $_SESSION["username"];
            $sql = "SELECT * FROM `user_response` WHERE `username` = '$username'";
        }
        // Execute the query
        $result = mysqli_query($link, $sql);

        // Check if any rows were returned
        if (mysqli_num_rows($result) > 0) {
            // Output data of each row
            // 
            // response_id	
            // username	
            // formName	
            // predict_percent	
            // response_sub_dt

            while ($row = mysqli_fetch_assoc($result)) {
                $suide = "Non-Suicide";
                if($row['predict_percent']>70){
                    $suide = "Suicide";
                }
                ?>
        
                <tr>
                    <?php
                    if ($_SESSION['role'] == 1) {
                    ?>
                        <td><?php echo $row['username'] ?></td>
                    <?php
                    }
                    ?>
                    <td><?php echo $row['formName'] ?></td>
                    <td><?php echo $row['predict_percent'] ?></td>
                    <td><?php echo $row['response_sub_dt'] ?></td>
                    <td><?php echo $suide?></td>

                </tr>
        <?php
            }
        }
        // else {
        //     // echo "0 results";
        // }
        ?>

    </tbody>
</table>
<!--  Response table end -->

<?php
// footer
include("partials/footer.php")
?>
<script>
    $(document).ready(function() {
        $('#MyTable').DataTable({
            initComplete: function() {
                this.api().columns().every(function() {
                    var column = this;
                    var select = $('<select><option value=""></option></select>')
                        .appendTo($(column.footer()).empty())
                        .on('change', function() {
                            var val = $.fn.dataTable.util.escapeRegex(
                                $(this).val()
                            );
                            //to select and search from grid
                            column
                                .search(val ? '^' + val + '$' : '', true, false)
                                .draw();
                        });

                    column.data().unique().sort().each(function(d, j) {
                        select.append('<option value="' + d + '">' + d + '</option>')
                    });
                });
            }
        });
    });
</script>