<?php
// navbar
include("partials/navbar.php")
?>

<div class="container-xxl py-5 bg-primary hero-header mb-5">
    <div class="container my-5 py-5 px-lg-5">
        <div class="row g-5 py-5">
            <div class="col-12 text-center">
                <h1 class="text-white animated zoomIn">Contact Us</h1>
                <hr class="bg-white mx-auto mt-0" style="width: 90px;">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb justify-content-center">
                        <li class="breadcrumb-item"><a class="text-white" href="#">Home</a></li>
                        <li class="breadcrumb-item"><a class="text-white" href="#">Pages</a></li>
                        <li class="breadcrumb-item text-white active" aria-current="page">Contact</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>
</div><!-- <br><br><br><br><br>  -->
<!-- form tabs start -->
<div id="wrapper">
    <div id="tabContainer">
        <div id="tabs">
            <ul>
                <li id="tabHeader_1">Friendship</li>
                <li id="tabHeader_2">Relationship</li>
                <li id="tabHeader_3">Money</li>
                <li id="tabHeader_4">Education</li>
            </ul>
        </div>
        <div id="tabscontent">
            <div class="tabpage" id="tabpage_1">
                <!-- Tab1 -->
                <!-- Form1 start -->
                <form id="form">
                    <h3>Fill if you feel like you depressed due to friends</h3>
                    <!-- Question1 -->
                    <div class="form-control">
                        <label>
                            => Have you ever felt like you don't have any genuine friends?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="friendshipQ1">
                            <input type="radio" name="friendshipQ1" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="friendshipQ1">
                            <input type="radio" name="friendshipQ1" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="friendshipQ1">
                            <input type="radio" name="friendshipQ1" value="Never" required>Never</input>
                        </label>
                    </div>

                    <!-- Question2 -->
                    <div class="form-control">
                        <label>
                            => Have you ever felt like your friends don't really care about you?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="friendshipQ2">
                            <input type="radio" name="friendshipQ2" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="friendshipQ3">
                            <input type="radio" name="friendshipQ2" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="friendshipQ3">
                            <input type="radio" name="friendshipQ2" value="Never" required>Never</input>
                        </label>
                    </div>

                    <!-- Question3 -->
                    <div class="form-control">
                        <label>
                            => Have you ever felt like your friends use you for their own benefit?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="friendshipQ3">
                            <input type="radio" name="friendshipQ3" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="friendshipQ3">
                            <input type="radio" name="friendshipQ3" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="friendshipQ3">
                            <input type="radio" name="friendshipQ3" value="Never" required>Never</input>
                        </label>
                    </div>

                    <!-- Question4 -->
                    <div class="form-control">
                        <label>
                            => Have you ever felt excluded or left out by your friends?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="friendshipQ4">
                            <input type="radio" name="friendshipQ4" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="friendshipQ4">
                            <input type="radio" name="friendshipQ4" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="friendshipQ4">
                            <input type="radio" name="friendshipQ4" value="Never" required>Never</input>
                        </label>
                    </div>

                    <!-- Question5 -->
                    <div class="form-control">
                        <label>
                            => Have you ever experienced betrayal or deceit from a friend?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="friendshipQ5">
                            <input type="radio" name="friendshipQ5" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="friendshipQ5">
                            <input type="radio" name="friendshipQ5" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="friendshipQ5">
                            <input type="radio" name="friendshipQ5" value="Never" required>Never</input>
                        </label>
                    </div>

                    <!-- Question6 -->
                    <div class="form-control">
                        <label>
                            => Have you ever felt like your friends don't really understand you?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="friendshipQ6">
                            <input type="radio" name="friendshipQ6" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="friendshipQ6">
                            <input type="radio" name="friendshipQ6" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="friendshipQ6">
                            <input type="radio" name="friendshipQ6" value="Never" required>Never</input>
                        </label>
                    </div>

                    <!-- Question7 -->
                    <div class="form-control">
                        <label>
                            => Have you ever been bullied or harassed by your friends?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="friendshipQ7">
                            <input type="radio" name="friendshipQ7" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="friendshipQ7">
                            <input type="radio" name="friendshipQ7" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="friendshipQ7">
                            <input type="radio" name="friendshipQ7" value="Never" required>Never</input>
                        </label>
                    </div>

                    <!-- Question8 -->
                    <div class="form-control">
                        <label>
                            => Did you ever felt alone being wit your friends?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="friendshipQ8">
                            <input type="radio" name="friendshipQ8" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="friendshipQ8">
                            <input type="radio" name="friendshipQ8" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="friendshipQ8">
                            <input type="radio" name="friendshipQ8" value="Never" required>Never</input>
                        </label>
                    </div>

                    <!-- Question9 -->
                    <div class="form-control">
                        <label>
                            => Have you ever felt that your friendship is one sided?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="friendshipQ9">
                            <input type="radio" name="friendshipQ9" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="friendshipQ9">
                            <input type="radio" name="friendshipQ9" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="friendshipQ9">
                            <input type="radio" name="friendshipQ9" value="Never" required>Never</input>
                        </label>
                    </div>

                    <!-- Question10 -->
                    <div class="form-control">
                        <label>
                            => Have you ever feel replacable being as a true friend too?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="friendshipQ10">
                            <input type="radio" name="friendshipQ10" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="friendshipQ10">
                            <input type="radio" name="friendshipQ10" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="friendshipQ10">
                            <input type="radio" name="friendshipQ10" value="Never" reuired>Never</input>
                        </label>
                    </div>


                    <!-- Multi-line Text Input Control -->
                    <button type="button" id="friendSubmit" style="width:100%">
                        Submit
                    </button>
                </form>
                <!-- form1 end -->
            </div>

            <div class="tabpage hidden" id="tabpage_2">
                <!-- Tab1 -->
                <!-- Form1 start -->
                <form id="form">
                    <h3>Fill if you feel like you have Relationship problem</h3>
                    <!-- Question1 -->
                    <div class="form-control">
                        <label>
                            => How often do you feel that you lack companionship?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="relationshipQ1">
                            <input type="radio" name="relationshipQ1" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="relationshipQ1">
                            <input type="radio" name="relationshipQ1" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="relationshipQ1">
                            <input type="radio" name="relationshipQ1" value="Never" required>Never</input>
                        </label>
                    </div>

                    <!-- Question2 -->
                    <div class="form-control">
                        <label>
                            => How often do you feel that there is no one you can turn to?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="relationshipQ2">
                            <input type="radio" name="relationshipQ2" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="relationshipQ2">
                            <input type="radio" name="relationshipQ2" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="relationshipQ2">
                            <input type="radio" name="relationshipQ2" value="Never" required>Never</input>
                        </label>
                    </div>

                    <!-- Question3 -->
                    <div class="form-control">
                        <label>
                            => How often do you feel isolated from your partner?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="relationshipQ3">
                            <input type="radio" name="relationshipQ3" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="relationshipQ3">
                            <input type="radio" name="relationshipQ3" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="relationshipQ3">
                            <input type="radio" name="relationshipQ3" value="Never" required>Never</input>
                        </label>
                    </div>

                    <!-- Question4 -->
                    <div class="form-control">
                        <label>
                            => How often do you feel that you are not good for your partner?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="relationshipQ4">
                            <input type="radio" name="relationshipQ4" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="relationshipQ4">
                            <input type="radio" name="relationshipQ4" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="relationshipQ4">
                            <input type="radio" name="relationshipQ4" value="Never" required>Never</input>
                        </label>
                    </div>

                    <!-- Question5 -->
                    <div class="form-control">
                        <label>
                            => How often do you feel that you dont have a special one who care about you?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="relationshipQ5">
                            <input type="radio" name="relationshipQ5" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="relationshipQ5">
                            <input type="radio" name="relationshipQ5" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="relationshipQ5">
                            <input type="radio" name="relationshipQ5" value="Never" required>Never</input>
                        </label>
                    </div>

                    <!-- Question6 -->
                    <div class="form-control">
                        <label>
                            => How often do you feel that you dont have a sense of belonging?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="relationshipQ6">
                            <input type="radio" name="relationshipQ6" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="relationshipQ6">
                            <input type="radio" name="relationshipQ6" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="relationshipQ6">
                            <input type="radio" name="relationshipQ6" value="Never" required>Never</input>
                        </label>
                    </div>

                    <!-- Question7 -->
                    <div class="form-control">
                        <label>
                            => How often do you feel that you dont have a sense of belonging?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="relationshipQ7">
                            <input type="radio" name="relationshipQ7" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="relationshipQ7">
                            <input type="radio" name="relationshipQ7" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="relationshipQ7">
                            <input type="radio" name="relationshipQ7" value="Never" required>Never</input>
                        </label>
                    </div>

                    <!-- Question8 -->
                    <div class="form-control">
                        <label>
                            => how often you feel that u dont have partner to share life problems?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="relationshipQ8">
                            <input type="radio" name="relationshipQ8" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="relationshipQ8">
                            <input type="radio" name="relationshipQ8" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="relationshipQ8">
                            <input type="radio" name="relationshipQ8" value="Never" required>Never</input>
                        </label>
                    </div>

                    <!-- Question9 -->
                    <div class="form-control">
                        <label>
                            => how much u feel that u dont have a special one at home waititng for u?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="relationshipQ9">
                            <input type="radio" name="relationshipQ9" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="relationshipQ9">
                            <input type="radio" name="relationshipQ9" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="relationshipQ9">
                            <input type="radio" name="relationshipQ9" value="Never" required>Never</input>
                        </label>
                    </div>

                    <!-- Question10 -->
                    <div class="form-control">
                        <label>
                            => How often do you feel left out?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="relationshipQ10">
                            <input type="radio" name="relationshipQ10" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="relationshipQ10">
                            <input type="radio" name="relationshipQ10" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="relationshipQ10">
                            <input type="radio" name="relationshipQ10" value="Never" required>Never</input>
                        </label>
                    </div>


                    <!-- Multi-line Text Input Control -->
                    <button type="button" id="relationSubmit" style="width:100%">
                        Submit
                    </button>
                </form>
                <!-- form1 end -->
            </div>

            <div class="tabpage hidden" id="tabpage_3">
                <!-- Tab1 -->
                <!-- Form1 start -->
                <form id="form">
                    <h3>Fill if you feel have money problems</h3>
                    <!-- Question1 -->
                    <div class="form-control">
                        <label>
                            =>How often u feel that u dont have moeny?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="moneyQ1">
                            <input type="radio" name="moneyQ1" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="moneyQ1">
                            <input type="radio" name="moneyQ1" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="moneyQ1">
                            <input type="radio" name="moneyQ1" value="Never" reuired>Never</input>
                        </label>
                    </div>

                    <!-- Question2 -->
                    <div class="form-control">
                        <label>
                            => how many days you feel that your friends are richer than you?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="moneyQ2">
                            <input type="radio" name="moneyQ2" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="moneyQ2">
                            <input type="radio" name="moneyQ2" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="moneyQ2">
                            <input type="radio" name="moneyQ2" value="Never" reuired>Never</input>
                        </label>
                    </div>

                    <!-- Question3 -->
                    <div class="form-control">
                        <label>
                            => how often you feel that you dont have a future without money?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="moneyQ3">
                            <input type="radio" name="moneyQ3" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="moneyQ3">
                            <input type="radio" name="moneyQ3" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="moneyQ3">
                            <input type="radio" name="moneyQ3" value="Never" reuired>Never</input>
                        </label>
                    </div>

                    <!-- Question4 -->
                    <div class="form-control">
                        <label>
                            => have you ever felt that money is more important than life?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="moneyQ4">
                            <input type="radio" name="moneyQ4" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="moneyQ4">
                            <input type="radio" name="moneyQ4" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="moneyQ4">
                            <input type="radio" name="moneyQ4" value="Never" reuired>Never</input>
                        </label>
                    </div>

                    <!-- Question5 -->
                    <div class="form-control">
                        <label>
                            => Have you ever felt that you will not survive without money?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="moneyQ5">
                            <input type="radio" name="moneyQ5" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="moneyQ5">
                            <input type="radio" name="moneyQ5" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="moneyQ5">
                            <input type="radio" name="moneyQ5" value="Never" reuired>Never</input>
                        </label>
                    </div>

                    <!-- Question6 -->
                    <div class="form-control">
                        <label>
                            => Do you ever feel bankrupt??
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="moneyQ6">
                            <input type="radio" name="moneyQ6" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="moneyQ6">
                            <input type="radio" name="moneyQ6" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="moneyQ6">
                            <input type="radio" name="moneyQ6" value="Never" reuired>Never</input>
                        </label>
                    </div>

                    <!-- Question7 -->
                    <div class="form-control">
                        <label>
                            => Do you feel that death is better than loans?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="moneyQ7">
                            <input type="radio" name="moneyQ7" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="moneyQ7">
                            <input type="radio" name="moneyQ7" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="moneyQ7">
                            <input type="radio" name="moneyQ7" value="Never" reuired>Never</input>
                        </label>
                    </div>

                    <!-- Question8 -->
                    <div class="form-control">
                        <label>
                            => Do you feel suicide is end of money problems?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="moneyQ8">
                            <input type="radio" name="moneyQ8" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="moneyQ8">
                            <input type="radio" name="moneyQ8" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="moneyQ8">
                            <input type="radio" name="moneyQ8" value="Never" reuired>Never</input>
                        </label>
                    </div>

                    <!-- Question9 -->
                    <div class="form-control">
                        <label>
                            => Do you feel money is like air you cant survive without it?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="moneyQ9">
                            <input type="radio" name="moneyQ9" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="moneyQ9">
                            <input type="radio" name="moneyQ9" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="moneyQ9">
                            <input type="radio" name="moneyQ9" value="Never" reuired>Never</input>
                        </label>
                    </div>

                    <!-- Question10 -->
                    <div class="form-control">
                        <label>
                            => Is being rich matter to you any time?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="moneyQ10">
                            <input type="radio" name="moneyQ10" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="moneyQ10">
                            <input type="radio" name="moneyQ10" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="moneyQ10">
                            <input type="radio" name="moneyQ10" value="Never" reuired>Never</input>
                        </label>
                    </div>


                    <!-- Multi-line Text Input Control -->
                    <button type="button" style="width:100%" id="moneySubmit">
                        Submit
                    </button>
                </form>
                <!-- form1 end -->
            </div>

            <div class="tabpage hidden" id="tabpage_4">
                <!-- Tab1 -->
                <!-- Form1 start -->
                <form id="form">
                    <h3>Fill if you feel have education problem</h3>
                    <!-- Question1 -->
                    <div class="form-control">
                        <label>
                            => Do you feel doing hard studies too cant make you win?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="educattionQ1">
                            <input type="radio" name="educattionQ1" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="educattionQ1">
                            <input type="radio" name="educattionQ1" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="educattionQ1">
                            <input type="radio" name="educattionQ1" value="Never" reuired>Never</input>
                        </label>
                    </div>

                    <!-- Question2 -->
                    <div class="form-control">
                        <label>
                            => Have you ever felt like you don't have any mentor to motivate you for your studies?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="educattionQ2">
                            <input type="radio" name="educattionQ2" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="educattionQ2">
                            <input type="radio" name="educattionQ2" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="educattionQ2">
                            <input type="radio" name="educattionQ2" value="Never" reuired>Never</input>
                        </label>
                    </div>

                    <!-- Question3 -->
                    <div class="form-control">
                        <label>
                            => Have you ever felt like your academic performance is negatively impacting your mental
                            health or well-being?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="educattionQ3">
                            <input type="radio" name="educattionQ3" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="educattionQ3">
                            <input type="radio" name="educattionQ3" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="educattionQ3">
                            <input type="radio" name="educattionQ3" value="Never" reuired>Never</input>
                        </label>
                    </div>

                    <!-- Question4 -->
                    <div class="form-control">
                        <label>
                            => Have you ever felt like you are constantly competing with your peers to achieve the
                            highest grades?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="educattionQ4">
                            <input type="radio" name="educattionQ4" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="educattionQ4">
                            <input type="radio" name="educattionQ4" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="educattionQ4">
                            <input type="radio" name="educattionQ4" value="Never" reuired>Never</input>
                        </label>
                    </div>

                    <!-- Question5 -->
                    <div class="form-control">
                        <label>
                            => Have you ever experienced academic failure or received grades that were significantly
                            lower than you expected?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="educattionQ5">
                            <input type="radio" name="educattionQ5" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="educattionQ5">
                            <input type="radio" name="educattionQ5" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="educattionQ5">
                            <input type="radio" name="educattionQ5" value="Never" reuired>Never</input>
                        </label>
                    </div>

                    <!-- Question6 -->
                    <div class="form-control">
                        <label>
                            => Have you ever experienced significant stress or anxiety related to your academic
                            performance or results?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="educattionQ6">
                            <input type="radio" name="educattionQ6" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="educattionQ6">
                            <input type="radio" name="educattionQ6" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="educattionQ6">
                            <input type="radio" name="educattionQ6" value="Never" reuired>Never</input>
                        </label>
                    </div>

                    <!-- Question7 -->
                    <div class="form-control">
                        <label>
                            => Have you ever felt like your academic performance is the only thing that matters to your
                            family or peers?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="reducattionQ7">
                            <input type="radio" name="educattionQ7" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="reducattionQ7">
                            <input type="radio" name="educattionQ7" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="reducattionQ7">
                            <input type="radio" name="educattionQ7" value="Never" reuired>Never</input>
                        </label>
                    </div>

                    <!-- Question8 -->
                    <div class="form-control">
                        <label>
                            => Have you ever felt like you are not smart enough to succeed academically?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="educattionQ8">
                            <input type="radio" name="educattionQ8" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="educattionQ8">
                            <input type="radio" name="educattionQ8" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="educattionQ8">
                            <input type="radio" name="educattionQ8" value="Never" reuired>Never</input>
                        </label>
                    </div>

                    <!-- Question9 -->
                    <div class="form-control">
                        <label>
                            => Have you ever felt like your academic performance defines your worth as a person?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="educattionQ9">
                            <input type="radio" name="educattionQ9" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="educattionQ9">
                            <input type="radio" name="educattionQ9" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="educattionQ9">
                            <input type="radio" name="educattionQ9" value="Never" reuired>Never</input>
                        </label>
                    </div>

                    <!-- Question10 -->
                    <div class="form-control">
                        <label>
                            => Have you ever felt overwhelming pressure to perform academically?
                        </label>
                        <!-- Input Type Radio Button -->
                        <label for="educattionQ10">
                            <input type="radio" name="educattionQ10" value="Everytime" required>Everytime</input>
                        </label>
                        <label for="educattionQ10">
                            <input type="radio" name="educattionQ10" value="Sometime" required>Sometime</input>
                        </label>
                        <label for="educattionQ10">
                            <input type="radio" name="educattionQ10" value="Never" reuired>Never</input>
                        </label>
                    </div>

                    <!-- Multi-line Text Input Control -->
                    <button type="button" id="educattionSubmit" style="width:100%">
                        Submit
                    </button>
                </form>
                <!-- form1 end -->
            </div>

        </div>
    </div>
</div>
<!-- form tab end -->

<?php
// footer
include("partials/footer.php")
?>

<!-- js file -->

<script>
    // getPercent
    function getPercent(everytime, sometime, never, quoteCat) {
        function greatEvery() {
            // Logic for evertime greatest start
            if (everytime >= 4 && everytime <= 5) {
                min = 60;
                max = 70;
                randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
                console.log("everytime >= 4 && everytime <= 5");
            } else if (everytime >= 6 && everytime <= 8) {
                min = 70;
                max = 90;
                randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
                console.log("everytime >= 6 && everytime <= 8");
            } else {
                min = 90;
                max = 100;
                randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
                console.log("else greatEvery");
            }
            // Logic for evertime greatest end
        }

        function greatSome() {
            // Logic for sometime greatest start
            if (sometime >= 4 && sometime <= 5) {
                min = 40;
                max = 47;
                randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
                console.log("sometime >= 4 && sometime <= 5");
            } else if (sometime >= 6 && sometime <= 8) {
                min = 47;
                max = 53;
                randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
                console.log("sometime >= 6 && sometime <= 8");
            } else {
                min = 53;
                max = 60;
                randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
                console.log("else sometime");
            }
            // Logic for sometime greatest end
        }

        function greatNever() {
            // Logic for never greatest start
            if (never >= 4 && never <= 5) {
                min = 30;
                max = 40;
                randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
                console.log("never >= 4 && never <= 5");
            } else if (never >= 6 && never <= 8) {
                min = 15;
                max = 30;
                randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
                console.log("never >= 6 && never <= 8");
            } else {
                min = 1;
                max = 15;
                randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
                console.log("else never");
            }
            // Logic for never greatest end
        }
        if (everytime > sometime && everytime > never) {
            // greatestNum = everytime;
            // greatestVar = 'everytime';
            greatEvery();
        } else if (sometime > everytime && sometime > never) {
            // greatestNum = sometime;
            // greatestVar = 'sometime';
            greatSome();
        } else if (never > everytime && never > sometime) {
            // greatestNum = never;
            // greatestVar = 'never';
            greatNever();
        } else {
            // greatestNum = everytime;
            // greatestVar = 'everytime';
            greatEvery();
        }
        // console.log(randomNumber);
        // localStorage.setItem("suicidePercent",randomNumber);

        if (everytime === sometime && sometime === never) {
            // console.log('hoich nahi skta');
            min = 1;
            max = 100;
            randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
            console.log();
        } else if (everytime === sometime) {
            // console.log(`everytime and sometime are equal to ${everytime}.`);
            if (everytime == 4 && sometime == 4) {
                // 4,4,2
                min = 70;
                max = 80;
                randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
                console.log("everytime == 4 && sometime == 4");
            }
        } else if (everytime === never) {
            // console.log(`everytime and never are equal to ${everytime}.`);
            // 4,2,4
            if (everytime == 4 && never == 4) {
                min = 40;
                max = 50;
                randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
                console.log("everytime === never");
            }
        } else if (sometime === never) {
            // console.log(`sometime and never are equal to ${sometime}.`);
            if (never == 4 && sometime == 4) {
                min = 30;
                max = 40;
                randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
                console.log("sometime === never");
            }
        } else {
            console.log("None of the numbers are equal.");
        }
        console.log(randomNumber);
        console.log(quoteCat);
        localStorage.setItem("suicidePercent", randomNumber);

        // put quotes:
        // Function to get a random integer between min (inclusive) and max (inclusive)
        function getRandomInt(min, max) {
            return Math.floor(Math.random() * (max - min + 1)) + min;
        }

        // Fetch the text file
        fetch('quotes.txt')
            .then(response => response.text())
            .then(data => {
                // Split the data into an array of quotes
                const quotesArray = data.split('\n');

                // Select a random index from the array
                const randomIndex = getRandomInt(0, quotesArray.length - 1);

                // Get the random quote
                const randomQuote = quotesArray[randomIndex];
                localStorage.setItem("randQuote", randomQuote);
                // Display the random quote on your website
                // document.getElementById('quote').textContent = randomQuote;
            })
            .catch(error => console.error('Error fetching quotes:', error));

        localStorage.setItem("quote_cat", quoteCat);
        document.cookie = "getSuicidePer=" + randomNumber;
        document.cookie = "quote_cat=" + quoteCat;

        // send data
        // Create a new XMLHttpRequest object
        var xhr = new XMLHttpRequest();

        // Define the request URL and method
        var url = "responseResult.php";
        var method = "POST";
        var newSub = true;

        // getQuotes
        // Define the request parameters
        var params = "formName=" + encodeURIComponent(quoteCat) + "&getSuicidePer=" + encodeURIComponent(randomNumber) + "&newSub=" + encodeURIComponent(newSub);

        // Send the request using AJAX
        xhr.open(method, url, true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function() {
            if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                // Handle the response from the server
                console.log(xhr.responseText);
            }
        };
        xhr.send(params);
        // send data end
    }

    // show result
    function showResult(everytimeQues, sometimeQues, neverQues, catQues) {
        if (
            everytimeQues == 0 &&
            sometimeQues == 0 &&
            neverQues == 0
        ) {} else {
            // console.log("Kuch to hua click freindship");
            responseResult = window.open("responseResult.php", "_self");
            // responseResult.document.getElementById("displaySuicidePercent").innerText="hello";
            getPercent(everytimeQues, sometimeQues, neverQues, catQues);

        }
    }
    // tab page 1 start
    let everytimeFriendship = 0;
    let sometimeFriendship = 0;
    let neverFriendship = 0;
    let friendSubmit = document.getElementById("friendSubmit");
    friendSubmit.addEventListener("click", function(e) {
        console.log("Bc friendship click hua");
        e.preventDefault();
        for (i = 1; i <= 10; i++) {
            let ch = document.querySelector(
                'input[name="friendshipQ' + i + '"]:checked'
            ).value;
            // console.log(ch);
            if (ch == "Everytime") {
                everytimeFriendship++;
            }
            if (ch == "Sometime") {
                sometimeFriendship++;
            }
            if (ch == "Never") {
                neverFriendship++;
            }
        }
        console.log(everytimeFriendship);
        console.log(sometimeFriendship);
        console.log(neverFriendship);
        // var ele = document.getElementsByName('friendshipQ1');
        showResult(everytimeFriendship, sometimeFriendship, neverFriendship, "friendship");
    });
    // tab page 1 end

    // tab page 2 start
    let everytimeRelation = 0;
    let sometimeRelation = 0;
    let neverRelation = 0;

    let relationSubmit = document.getElementById("relationSubmit");
    relationSubmit.addEventListener("click", function(e) {
        console.log("Bc relation click hua");

        e.preventDefault();
        for (i = 1; i <= 10; i++) {
            let ch = document.querySelector(
                'input[name="relationshipQ' + i + '"]:checked'
            ).value;
            // console.log(ch);
            if (ch == "Everytime") {
                everytimeRelation++;
            }
            if (ch == "Sometime") {
                sometimeRelation++;
            }
            if (ch == "Never") {
                neverRelation++;
            }
        }
        console.log(everytimeRelation);
        console.log(sometimeRelation);
        console.log(neverRelation);

        showResult(everytimeRelation, sometimeRelation, neverRelation, "relationship");
    });
    // tab page 2 end

    // tab page 3 start
    let everytimeMoney = 0;
    let sometimeMoney = 0;
    let neverMoney = 0;

    let moneySubmit = document.getElementById("moneySubmit");
    moneySubmit.addEventListener("click", function(e) {
        console.log("Bc Money click hua");

        e.preventDefault();
        for (i = 1; i <= 10; i++) {
            let ch = document.querySelector(
                'input[name="moneyQ' + i + '"]:checked'
            ).value;
            // console.log(ch);
            if (ch == "Everytime") {
                everytimeMoney++;
            }
            if (ch == "Sometime") {
                sometimeMoney++;
            }
            if (ch == "Never") {
                neverMoney++;
            }
        }
        console.log(everytimeMoney);
        console.log(sometimeMoney);
        console.log(neverMoney);
        showResult(everytimeMoney, sometimeMoney, neverMoney, "money");
    });
    // tab page 3 end

    // tab page 3 start

    let everytimeEducattion = 0;
    let sometimeEducattion = 0;
    let neverEducattion = 0;

    let educattionubmit = document.getElementById("educattionSubmit");
    educattionSubmit.addEventListener("click", function(e) {
        console.log("Bc Education click hua");

        e.preventDefault();
        for (i = 1; i <= 10; i++) {
            let ch = document.querySelector(
                'input[name="educattionQ' + i + '"]:checked'
            ).value;
            // console.log(ch);
            if (ch == "Everytime") {
                everytimeEducattion++;
            }
            if (ch == "Sometime") {
                sometimeEducattion++;
            }
            if (ch == "Never") {
                neverEducattion++;
            }
        }
        console.log(everytimeEducattion);
        console.log(sometimeEducattion);
        console.log(neverEducattion);
        showResult(everytimeEducattion, sometimeEducattion, neverEducattion, "educattion");
    });
    // tab page 3 end
</script>