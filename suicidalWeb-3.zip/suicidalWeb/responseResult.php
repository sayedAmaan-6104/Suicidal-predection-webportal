<?php
include("partials/navbar.php");
include("partials/_connectDb.php");
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $newSub = $_POST["newSub"];
  if ($newSub) {

    $username = $_SESSION["username"];
    $formName = $_POST["formName"];
    $getSuicidePer = $_POST["getSuicidePer"];

    $sql = "INSERT INTO `user_response` (`response_id`, `username`, `formName`, `predict_percent`, `response_sub_dt`) VALUES (NULL, '$username', '$formName', '$getSuicidePer', current_timestamp());";
    if (mysqli_query($link, $sql)) {
      echo "Record inserted successfully";
    } else {
      echo "Error inserting record: " . mysqli_error($link);
    }
    $newSub = false;
  }
}
?>
<div class="container-xxl py-5 bg-primary hero-header mb-5">
  <div class="container my-5 py-5 px-lg-5">
    <div class="row g-5 py-5">

    </div>
  </div>
</div>
</div>
</div>

<br>

<!-- show result start -->
<div class="showResult">
  <h1 id="displaySuicidePercent">
    <script>
      getQuoteCat = localStorage.getItem("quote_cat");
      getSuicidePer = localStorage.getItem("suicidePercent");
      document.getElementById("displaySuicidePercent").textContent = "Your suicide percent is: " + getSuicidePer + "%";
      // document.cookie = "getSuicidePer="+ getSuicidePer;
      // <?php echo $_COOKIE["getSuicidePer"]; ?>
    </script>

  </h1>
</div>
<br>
<!-- show result end -->
<!-- quote card start -->

<div class="quoteContainer">
  <blockquote id="displayQuote">
    <script>
      getQuote = localStorage.getItem("randQuote");
      document.getElementById("displayQuote").textContent = getQuote;
    </script>

  </blockquote>
</div>
<!-- quote card end -->

<!-- button for game -->
<div class="gameButton">
  <h2 style="text-align:center; margin: auto; padding:1%">Let's play a game</h2>
  <a href="game1/game1.html">
    <button class="glow-on-hover" type="button" style="width:auto; margin:auto; padding:1%">Play The Game</button>
  </a>
</div>
<!-- button for ganme end -->
<?php
include("partials/footer.php");
?>