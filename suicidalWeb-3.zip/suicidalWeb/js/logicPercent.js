// var everytime = 10;
// var sometime = 20;
// var never = 30;
// var greatest;

function getPercentOld(everytime, sometime, never) {
  if (everytime > sometime) {
    if (everytime > never) {
      // greatest = everytime;
      // Logic for evertime greatest start
      if (everytime >= 4 && everytime <= 5) {
        min = 60;
        max = 70;
        randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      } else if (everytime >= 6 && everytime <= 8) {
        min = 70;
        max = 90;
        randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      } else {
        min = 90;
        max = 100;
        randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      }
      // Logic for evertime greatest end
    } else {
      // greatest = never;
      // Logic for never greatest start
      if (everytime > 4 && everytime < 5) {
        min = 1;
        max = 15;
        randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      } else if (everytime > 6 && everytime < 8) {
        min = 15;
        max = 30;
        randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      } else {
        min = 30;
        max = 40;
        randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      }
      // Logic for never greatest end
    }
  } else {
    if (sometime > never) {
      // greatest = sometime;
      // Logic for sometime greatest start
      if (everytime > 4 && everytime < 5) {
        min = 40;
        max = 47;
        randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      } else if (everytime > 6 && everytime < 8) {
        min = 47;
        max = 53;
        randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      } else {
        min = 53;
        max = 60;
        randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      }
      // Logic for sometime greatest end
    } else {
      // greatest = never;
      // Logic for never greatest start
      if (everytime > 4 && everytime < 5) {
        min = 1;
        max = 15;
        randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      } else if (everytime > 6 && everytime < 8) {
        min = 15;
        max = 30;
        randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      } else {
        min = 30;
        max = 40;
        randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      }
      // Logic for never greatest end
    }
  }
  console.log("The greatest number is " + randomNumber);
}

getPercentOld(4, 3, 3);

// new logic 2
var everytime = 10;
var sometime = 20;
var never = 30;
var greatest;

function getPercentOld1(everytime, sometime, never) {
  if (everytime > sometime) {
    if (everytime > never) {
      // greatest = everytime;
      // Logic for evertime greatest start
      if (everytime >= 4 && everytime <= 5) {
        min = 60;
        max = 70;
        randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      } else if (everytime >= 6 && everytime <= 8) {
        min = 70;
        max = 90;
        randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      } else {
        min = 90;
        max = 100;
        randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      }
      // Logic for evertime greatest end
    } else if (everytime === never) {
      // greatest = everytime + " and " + never + " are equal";
      // 4,2,4
      min = 40;
      max = 50;
      randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
    } else {
      // greatest = never;
      // Logic for never greatest start
      if (everytime >= 4 && everytime <= 5) {
        min = 1;
        max = 15;
        randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      } else if (everytime >= 6 && everytime <= 8) {
        min = 15;
        max = 30;
        randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      } else {
        min = 30;
        max = 40;
        randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      }
      // Logic for never greatest end
    }
  } else if (sometime > everytime) {
    if (sometime > never) {
      // greatest = sometime;
      // Logic for evertime greatest start
      if (everytime >= 4 && everytime <= 5) {
        min = 60;
        max = 70;
        randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      } else if (everytime >= 6 && everytime <= 8) {
        min = 70;
        max = 90;
        randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      } else {
        min = 90;
        max = 100;
        randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      }
      // Logic for evertime greatest end
    } else if (sometime === never) {
      // greatest = sometime + " and " + never + " are equal";
      // 2,4,4
      min = 30;
      max = 40;
      randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
    } else {
      // greatest = never;
      // Logic for never greatest start
      if (everytime > 4 && everytime < 5) {
        min = 1;
        max = 15;
        randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      } else if (everytime > 6 && everytime < 8) {
        min = 15;
        max = 30;
        randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      } else {
        min = 30;
        max = 40;
        randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      }
      // Logic for never greatest end
    }
  } else {
    if (everytime === sometime && sometime === never) {
      greatest = "All three numbers are equal";
      // never will execute
      min = 1;
      max = 100;
      randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
    } else {
      // greatest = everytime + " and " + sometime + " are equal";
      // 4,4,2
      min = 60;
      max = 70;
      randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
    }
  }
  console.log("The greatest number is " + randomNumber);
}
getPercentOld1(4, 4, 2);

// new Logic 3

function getPercent(everytime, sometime, never) {
  function greatEvery() {
    // Logic for evertime greatest start
    if (everytime >= 4 && everytime <= 5) {
      min = 60;
      max = 70;
      randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      console.log("everytime >= 4 && everytime <= 5");
    } else if (everytime >= 6 && everytime <= 8) {
      min = 70;
      max = 90;
      randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      console.log("everytime >= 6 && everytime <= 8");
    } else {
      min = 90;
      max = 100;
      randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      console.log("else greatEvery");
    }
    // Logic for evertime greatest end
  }
  function greatSome() {
    // Logic for sometime greatest start
    if (sometime >= 4 && sometime <= 5) {
      min = 40;
      max = 47;
      randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      console.log("sometime >= 4 && sometime <= 5");
    } else if (sometime >= 6 && sometime <= 8) {
      min = 47;
      max = 53;
      randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      console.log("sometime >= 6 && sometime <= 8");
    } else {
      min = 53;
      max = 60;
      randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      console.log("else sometime");
    }
    // Logic for sometime greatest end
  }
  function greatNever() {
    // Logic for never greatest start
    if (never >= 4 && never <= 5) {
      min = 30;
      max = 40;
      randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      console.log("never >= 4 && never <= 5");
    } else if (never >= 6 && never <= 8) {
      min = 15;
      max = 30;
      randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      console.log("never >= 6 && never <= 8");
    } else {
      min = 1;
      max = 15;
      randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      console.log("else never");
    }
    // Logic for never greatest end
  }
  if (everytime > sometime && everytime > never) {
    // greatestNum = everytime;
    // greatestVar = 'everytime';
    greatEvery();
  } else if (sometime > everytime && sometime > never) {
    // greatestNum = sometime;
    // greatestVar = 'sometime';
    greatSome();
  } else if (never > everytime && never > sometime) {
    // greatestNum = never;
    // greatestVar = 'never';
    greatNever();
  } else {
    // greatestNum = everytime;
    // greatestVar = 'everytime';
    greatEvery();
  }
  // console.log(randomNumber);
  // localStorage.setItem("suicidePercent",randomNumber);

  if (everytime === sometime && sometime === never) {
    // console.log('hoich nahi skta');
    min = 1;
    max = 100;
    randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
    console.log();
  } else if (everytime === sometime) {
    // console.log(`everytime and sometime are equal to ${everytime}.`);
    if (everytime == 4 && sometime == 4) {
      // 4,4,2
      min = 70;
      max = 80;
      randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      console.log("everytime == 4 && sometime == 4");
    }
  } else if (everytime === never) {
    // console.log(`everytime and never are equal to ${everytime}.`);
    // 4,2,4
    if (everytime == 4 && never == 4) {
      min = 40;
      max = 50;
      randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
      console.log("everytime === never");
    }
  }else if (sometime === never) {
    // console.log(`sometime and never are equal to ${sometime}.`);
    if (never == 4 && sometime == 4) {
    min = 30;
    max = 40;
    randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
    console.log("sometime === never");
    }
  }
  else {
    console.log("None of the numbers are equal.");
  }
  console.log(randomNumber);
  localStorage.setItem("suicidePercent", randomNumber);
}
getPercent(1, 8, 1);
