// // getPercent
// function getPercent(everytime, sometime, never,quoteCat) {
//   function greatEvery() {
//     // Logic for evertime greatest start
//     if (everytime >= 4 && everytime <= 5) {
//       min = 60;
//       max = 70;
//       randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
//       console.log("everytime >= 4 && everytime <= 5");
//     } else if (everytime >= 6 && everytime <= 8) {
//       min = 70;
//       max = 90;
//       randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
//       console.log("everytime >= 6 && everytime <= 8");
//     } else {
//       min = 90;
//       max = 100;
//       randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
//       console.log("else greatEvery");
//     }
//     // Logic for evertime greatest end
//   }
//   function greatSome() {
//     // Logic for sometime greatest start
//     if (sometime >= 4 && sometime <= 5) {
//       min = 40;
//       max = 47;
//       randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
//       console.log("sometime >= 4 && sometime <= 5");
//     } else if (sometime >= 6 && sometime <= 8) {
//       min = 47;
//       max = 53;
//       randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
//       console.log("sometime >= 6 && sometime <= 8");
//     } else {
//       min = 53;
//       max = 60;
//       randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
//       console.log("else sometime");
//     }
//     // Logic for sometime greatest end
//   }
//   function greatNever() {
//     // Logic for never greatest start
//     if (never >= 4 && never <= 5) {
//       min = 30;
//       max = 40;
//       randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
//       console.log("never >= 4 && never <= 5");
//     } else if (never >= 6 && never <= 8) {
//       min = 15;
//       max = 30;
//       randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
//       console.log("never >= 6 && never <= 8");
//     } else {
//       min = 1;
//       max = 15;
//       randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
//       console.log("else never");
//     }
//     // Logic for never greatest end
//   }
//   if (everytime > sometime && everytime > never) {
//     // greatestNum = everytime;
//     // greatestVar = 'everytime';
//     greatEvery();
//   } else if (sometime > everytime && sometime > never) {
//     // greatestNum = sometime;
//     // greatestVar = 'sometime';
//     greatSome();
//   } else if (never > everytime && never > sometime) {
//     // greatestNum = never;
//     // greatestVar = 'never';
//     greatNever();
//   } else {
//     // greatestNum = everytime;
//     // greatestVar = 'everytime';
//     greatEvery();
//   }
//   // console.log(randomNumber);
//   // localStorage.setItem("suicidePercent",randomNumber);

//   if (everytime === sometime && sometime === never) {
//     // console.log('hoich nahi skta');
//     min = 1;
//     max = 100;
//     randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
//     console.log();
//   } else if (everytime === sometime) {
//     // console.log(`everytime and sometime are equal to ${everytime}.`);
//     if (everytime == 4 && sometime == 4) {
//       // 4,4,2
//       min = 70;
//       max = 80;
//       randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
//       console.log("everytime == 4 && sometime == 4");
//     }
//   } else if (everytime === never) {
//     // console.log(`everytime and never are equal to ${everytime}.`);
//     // 4,2,4
//     if (everytime == 4 && never == 4) {
//       min = 40;
//       max = 50;
//       randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
//       console.log("everytime === never");
//     }
//   }else if (sometime === never) {
//     // console.log(`sometime and never are equal to ${sometime}.`);
//     if (never == 4 && sometime == 4) {
//     min = 30;
//     max = 40;
//     randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
//     console.log("sometime === never");
//     }
//   }
//   else {
//     console.log("None of the numbers are equal.");
//   }
//   console.log(randomNumber);
//   console.log(quoteCat);
//   localStorage.setItem("suicidePercent", randomNumber);
//   localStorage.setItem("quote_cat", quoteCat);
// }

// // show result
// function showResult(everytimeQues,sometimeQues,neverQues,catQues) {
//   if (
//     everytimeQues == 0 &&
//     sometimeQues == 0 &&
//     neverQues == 0
//   ) {
//   } else {
//     // console.log("Kuch to hua click freindship");
//     responseResult = window.open("responseResult.php", "_self");
//     // responseResult.document.getElementById("displaySuicidePercent").innerText="hello";
//     getPercent(everytimeQues, sometimeQues, neverQues,catQues);
    
//   }
// }
// // tab page 1 start
// let everytimeFriendship = 0;
// let sometimeFriendship = 0;
// let neverFriendship = 0;
// let friendSubmit = document.getElementById("friendSubmit");
// friendSubmit.addEventListener("click", function (e) {
//   console.log("Bc friendship click hua");
//   e.preventDefault();
//   for (i = 1; i <= 10; i++) {
//     let ch = document.querySelector(
//       'input[name="friendshipQ' + i + '"]:checked'
//     ).value;
//     // console.log(ch);
//     if (ch == "Everytime") {
//       everytimeFriendship++;
//     }
//     if (ch == "Sometime") {
//       sometimeFriendship++;
//     }
//     if (ch == "Never") {
//       neverFriendship++;
//     }
//   }
//   console.log(everytimeFriendship);
//   console.log(sometimeFriendship);
//   console.log(neverFriendship);
//   // var ele = document.getElementsByName('friendshipQ1');
//   showResult(everytimeFriendship,sometimeFriendship,neverFriendship,"friendship");
// });
// // tab page 1 end

// // tab page 2 start
// let everytimeRelation = 0;
// let sometimeRelation = 0;
// let neverRelation = 0;

// let relationSubmit = document.getElementById("relationSubmit");
// relationSubmit.addEventListener("click", function (e) {
//   console.log("Bc relation click hua");

//   e.preventDefault();
//   for (i = 1; i <= 10; i++) {
//     let ch = document.querySelector(
//       'input[name="relationshipQ' + i + '"]:checked'
//     ).value;
//     // console.log(ch);
//     if (ch == "Everytime") {
//       everytimeRelation++;
//     }
//     if (ch == "Sometime") {
//       sometimeRelation++;
//     }
//     if (ch == "Never") {
//       neverRelation++;
//     }
//   }
//   console.log(everytimeRelation);
//   console.log(sometimeRelation);
//   console.log(neverRelation);

//   showResult(everytimeRelation,sometimeRelation,neverRelation,"relationship");
// });
// // tab page 2 end

// // tab page 3 start
// let everytimeMoney = 0;
// let sometimeMoney = 0;
// let neverMoney = 0;

// let moneySubmit = document.getElementById("moneySubmit");
// moneySubmit.addEventListener("click", function (e) {
//   console.log("Bc Money click hua");

//   e.preventDefault();
//   for (i = 1; i <= 10; i++) {
//     let ch = document.querySelector(
//       'input[name="moneyQ' + i + '"]:checked'
//     ).value;
//     // console.log(ch);
//     if (ch == "Everytime") {
//       everytimeMoney++;
//     }
//     if (ch == "Sometime") {
//       sometimeMoney++;
//     }
//     if (ch == "Never") {
//       neverMoney++;
//     }
//   }
//   console.log(everytimeMoney);
//   console.log(sometimeMoney);
//   console.log(neverMoney);
//   showResult(everytimeMoney,sometimeMoney,neverMoney,"money");
// });
// // tab page 3 end

// // tab page 3 start

// let everytimeEducattion = 0;
// let sometimeEducattion = 0;
// let neverEducattion = 0;

// let educattionubmit = document.getElementById("educattionSubmit");
// educattionSubmit.addEventListener("click", function (e) {
//   console.log("Bc Education click hua");

//   e.preventDefault();
//   for (i = 1; i <= 10; i++) {
//     let ch = document.querySelector(
//       'input[name="educattionQ' + i + '"]:checked'
//     ).value;
//     // console.log(ch);
//     if (ch == "Everytime") {
//       everytimeEducattion++;
//     }
//     if (ch == "Sometime") {
//       sometimeEducattion++;
//     }
//     if (ch == "Never") {
//       neverEducattion++;
//     }
//   }
//   console.log(everytimeEducattion);
//   console.log(sometimeEducattion);
//   console.log(neverEducattion);
//   showResult(everytimeEducattion,sometimeEducattion,neverEducattion,"educattion");
// });
// // tab page 3 end