-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 13, 2023 at 12:19 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `suicidalweb`
--

-- --------------------------------------------------------

--
-- Table structure for table `olddata`
--

CREATE TABLE `olddata` (
  `oldData_id` int(30) NOT NULL,
  `year` int(30) NOT NULL,
  `cause` varchar(255) NOT NULL,
  `total` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `olddata`
--

INSERT INTO `olddata` (`oldData_id`, `year`, `cause`, `total`) VALUES
(1, 2010, 'Dowry Dispute', 180),
(2, 2010, 'Drug Abuse/Addiction', 1),
(3, 2010, 'Ideological Causes/Hero Worshipping', 1),
(4, 2010, 'Suspected/Illicit Relation', 16),
(5, 2010, 'Fall in Social Reputation', 45),
(6, 2010, 'Insanity/Mental Illness', 176),
(7, 2010, 'Death of Dear Person', 25),
(8, 2010, 'Paralysis', 11),
(9, 2010, 'Other Causes (Please Specity)', 98),
(10, 2010, 'Illegitimate Pregnancy', 9),
(11, 2010, 'Professional/Career Problem', 8),
(12, 2010, 'Unemployment', 15),
(13, 2010, 'Family Problems', 1354),
(14, 2010, 'Physical Abuse (Rape/Incest Etc.)', 14),
(15, 2010, 'Failure in Examination', 198),
(16, 2010, 'Property Dispute', 2),
(17, 2010, 'Other Prolonged Illness', 315),
(18, 2010, 'Not having Children(Barrenness/Impotency', 39),
(19, 2010, 'Bankruptcy or Sudden change in Economic', 14),
(20, 2010, 'Causes Not known', 88),
(21, 2010, 'Cancer', 4),
(22, 2010, 'Cancellation/Non-Settlement of Marriage', 58),
(23, 2010, 'Illness (Aids/STD)', 6),
(24, 2010, 'Love Affairs', 97),
(25, 2010, 'Divorce', 6),
(26, 2010, 'Poverty', 24),
(27, 2010, 'Divorce', 9),
(28, 2010, 'Love Affairs', 114),
(29, 2010, 'Failure in Examination', 159),
(30, 2010, 'Ideological Causes/Hero Worshipping', 0),
(31, 2010, 'Illegitimate Pregnancy', 0),
(32, 2010, 'Professional/Career Problem', 60),
(33, 2010, 'Paralysis', 6),
(34, 2010, 'Poverty', 55),
(35, 2010, 'Illness (Aids/STD)', 18),
(36, 2010, 'Causes Not known', 136),
(37, 2010, 'Drug Abuse/Addiction', 341),
(38, 2010, 'Insanity/Mental Illness', 311),
(39, 2010, 'Family Problems', 1306),
(40, 2010, 'Fall in Social Reputation', 49),
(41, 2010, 'Dowry Dispute', 0),
(42, 2010, 'Bankruptcy or Sudden change in Economic', 131),
(43, 2010, 'Death of Dear Person', 26),
(44, 2010, 'Property Dispute', 10),
(45, 2010, 'Unemployment', 145),
(46, 2010, 'Suspected/Illicit Relation', 10),
(47, 2010, 'Cancer', 12),
(48, 2010, 'Other Prolonged Illness', 359),
(49, 2010, 'Not having Children(Barrenness/Impotency', 14),
(50, 2010, 'Physical Abuse (Rape/Incest Etc.)', 0),
(51, 2010, 'Cancellation/Non-Settlement of Marriage', 62),
(52, 2010, 'Other Causes (Please Specity)', 152),
(53, 2010, 'By coming under running vehicles/trains', 21),
(54, 2010, 'By Over Alcoholism', 0),
(55, 2010, 'By Jumping off Moving Vehicles/Trains', 5),
(56, 2010, 'By Jumping from (Building)', 8),
(57, 2010, 'By Other means (please specify)', 0),
(58, 2010, 'By Fire/Self Immolation', 552),
(59, 2010, 'By Overdose of sleeping pills', 5),
(60, 2010, 'By Consuming Insecticides', 692),
(61, 2010, 'By Fire-Arms', 0),
(62, 2010, 'By touching electric wires', 0),
(63, 2010, 'By Machine', 0),
(64, 2010, 'By Consuming Other Poison', 216),
(65, 2010, 'By Hanging', 972),
(66, 2010, 'By Jumping from (Other sites)', 2),
(67, 2010, 'By Self Infliction of injury', 6),
(68, 2010, 'By Drowning', 325),
(69, 2010, 'By Jumping from (Building)', 21),
(70, 2010, 'By Jumping off Moving Vehicles/Trains', 15),
(71, 2010, 'By Fire/Self Immolation', 203),
(72, 2010, 'By Jumping from (Other sites)', 2),
(73, 2010, 'By Machine', 0),
(74, 2010, 'By Hanging', 1542),
(75, 2010, 'By Self Infliction of injury', 12),
(76, 2010, 'By Consuming Other Poison', 311),
(77, 2010, 'By Drowning', 206),
(78, 2010, 'By Overdose of sleeping pills', 0),
(79, 2010, 'By touching electric wires', 1),
(80, 2010, 'By Consuming Insecticides', 1113),
(81, 2010, 'By Other means (please specify)', 0),
(82, 2010, 'By Over Alcoholism', 15),
(83, 2010, 'By coming under running vehicles/trains', 39),
(84, 2010, 'By Fire-Arms', 5),
(85, 2010, 'Farming/Agriculture Activity', 79),
(86, 2010, 'Others (Please Specify)', 8),
(87, 2010, 'Service (Private)', 93),
(88, 2010, 'House Wife', 1882),
(89, 2010, 'Service (Government)', 8),
(90, 2010, 'Self-employed (Business activity)', 3),
(91, 2010, 'Professional Activity', 42),
(92, 2010, 'Public Sector Undertaking', 3),
(93, 2010, 'Unemployed', 60),
(94, 2010, 'Student', 492),
(95, 2010, 'Others (Please Specify)', 134),
(96, 2010, 'Retired Person', 0),
(97, 2010, 'Public Sector Undertaking', 40),
(98, 2010, 'Farming/Agriculture Activity', 784),
(99, 2010, 'House Wife', 0),
(100, 2010, 'Unemployed', 365),
(101, 2010, 'Professional Activity', 265),
(102, 2010, 'Student', 427),
(103, 2010, 'Self-employed (Business activity)', 143),
(104, 2010, 'Others (Please Specify)', 792),
(105, 2010, 'Others (Please Specify)', 75),
(106, 2010, 'Service (Private)', 559),
(107, 2010, 'Retired Person', 0),
(108, 2010, 'Service (Government)', 35),
(109, 2011, 'Dowry Dispute', 171),
(110, 2011, 'Professional/Career Problem', 9),
(111, 2011, 'Unemployment', 10),
(112, 2011, 'Bankruptcy or Sudden change in Economic', 15),
(113, 2011, 'Other Prolonged Illness', 285),
(114, 2011, 'Insanity/Mental Illness', 162),
(115, 2011, 'Other Causes (Please Specity)', 126),
(116, 2011, 'Physical Abuse (Rape/Incest Etc.)', 16),
(117, 2011, 'Paralysis', 3),
(118, 2011, 'Family Problems', 1406),
(119, 2011, 'Causes Not known', 80),
(120, 2011, 'Divorce', 10),
(121, 2011, 'Drug Abuse/Addiction', 2),
(122, 2011, 'Cancellation/Non-Settlement of Marriage', 62),
(123, 2011, 'Death of Dear Person', 29),
(124, 2011, 'Not having Children(Barrenness/Impotency', 41),
(125, 2011, 'Poverty', 4),
(126, 2011, 'Suspected/Illicit Relation', 13),
(127, 2011, 'Illegitimate Pregnancy', 4),
(128, 2011, 'Love Affairs', 108),
(129, 2011, 'Cancer', 3),
(130, 2011, 'Fall in Social Reputation', 15),
(131, 2011, 'Ideological Causes/Hero Worshipping', 1),
(132, 2011, 'Failure in Examination', 146),
(133, 2011, 'Illness (Aids/STD)', 5),
(134, 2011, 'Property Dispute', 2),
(135, 2011, 'Divorce', 5),
(136, 2011, 'Failure in Examination', 147),
(137, 2011, 'Fall in Social Reputation', 14),
(138, 2011, 'Cancellation/Non-Settlement of Marriage', 75),
(139, 2011, 'Ideological Causes/Hero Worshipping', 2),
(140, 2011, 'Insanity/Mental Illness', 265),
(141, 2011, 'Dowry Dispute', 0),
(142, 2011, 'Illness (Aids/STD)', 8),
(143, 2011, 'Love Affairs', 128),
(144, 2011, 'Causes Not known', 173),
(145, 2011, 'Physical Abuse (Rape/Incest Etc.)', 0),
(146, 2011, 'Not having Children(Barrenness/Impotency', 9),
(147, 2011, 'Bankruptcy or Sudden change in Economic', 104),
(148, 2011, 'Illegitimate Pregnancy', 0),
(149, 2011, 'Family Problems', 1354),
(150, 2011, 'Other Prolonged Illness', 356),
(151, 2011, 'Paralysis', 3),
(152, 2011, 'Poverty', 43),
(153, 2011, 'Other Causes (Please Specity)', 187),
(154, 2011, 'Drug Abuse/Addiction', 353),
(155, 2011, 'Death of Dear Person', 31),
(156, 2011, 'Cancer', 8),
(157, 2011, 'Unemployment', 141),
(158, 2011, 'Suspected/Illicit Relation', 12),
(159, 2011, 'Property Dispute', 5),
(160, 2011, 'Professional/Career Problem', 54),
(161, 2011, 'By Consuming Insecticides', 662),
(162, 2011, 'By Machine', 0),
(163, 2011, 'By Jumping off Moving Vehicles/Trains', 10),
(164, 2011, 'By Fire/Self Immolation', 551),
(165, 2011, 'By Jumping from (Other sites)', 12),
(166, 2011, 'By Jumping from (Building)', 8),
(167, 2011, 'By Fire-Arms', 0),
(168, 2011, 'By Other means (please specify)', 1),
(169, 2011, 'By Hanging', 978),
(170, 2011, 'By Over Alcoholism', 1),
(171, 2011, 'By Drowning', 292),
(172, 2011, 'By coming under running vehicles/trains', 6),
(173, 2011, 'By touching electric wires', 1),
(174, 2011, 'By Consuming Other Poison', 196),
(175, 2011, 'By Self Infliction of injury', 5),
(176, 2011, 'By Overdose of sleeping pills', 5),
(177, 2011, 'By Consuming Other Poison', 267),
(178, 2011, 'By Fire/Self Immolation', 225),
(179, 2011, 'By touching electric wires', 1),
(180, 2011, 'By Jumping off Moving Vehicles/Trains', 14),
(181, 2011, 'By coming under running vehicles/trains', 37),
(182, 2011, 'By Consuming Insecticides', 1016),
(183, 2011, 'By Overdose of sleeping pills', 1),
(184, 2011, 'By Jumping from (Other sites)', 3),
(185, 2011, 'By Machine', 1),
(186, 2011, 'By Drowning', 217),
(187, 2011, 'By Jumping from (Building)', 15),
(188, 2011, 'By Self Infliction of injury', 10),
(189, 2011, 'By Over Alcoholism', 31),
(190, 2011, 'By Hanging', 1633),
(191, 2011, 'By Other means (please specify)', 2),
(192, 2011, 'By Fire-Arms', 4),
(193, 2011, 'House Wife', 1863),
(194, 2011, 'Self-employed (Business activity)', 11),
(195, 2011, 'Service (Government)', 13),
(196, 2011, 'Retired Person', 0),
(197, 2011, 'Public Sector Undertaking', 5),
(198, 2011, 'Others (Please Specify)', 110),
(199, 2011, 'Professional Activity', 20),
(200, 2011, 'Student', 437),
(201, 2011, 'Service (Private)', 82),
(202, 2011, 'Unemployed', 50),
(203, 2011, 'Farming/Agriculture Activity', 123),
(204, 2011, 'Others (Please Specify)', 14),
(205, 2011, 'Farming/Agriculture Activity', 727),
(206, 2011, 'Others (Please Specify)', 134),
(207, 2011, 'Retired Person', 4),
(208, 2011, 'Others (Please Specify)', 808),
(209, 2011, 'Self-employed (Business activity)', 168),
(210, 2011, 'Professional Activity', 209),
(211, 2011, 'Student', 441),
(212, 2011, 'Service (Government)', 35),
(213, 2011, 'Service (Private)', 633),
(214, 2011, 'Unemployed', 299),
(215, 2011, 'House Wife', 0),
(216, 2011, 'Public Sector Undertaking', 19),
(217, 2012, 'Physical Abuse (Rape/Incest Etc.)', 11),
(218, 2012, 'Ideological Causes/Hero Worshipping', 1),
(219, 2012, 'Other Prolonged Illness', 264),
(220, 2012, 'Divorce', 11),
(221, 2012, 'Suspected/Illicit Relation', 19),
(222, 2012, 'Love Affairs', 117),
(223, 2012, 'Failure in Examination', 156),
(224, 2012, 'Poverty', 11),
(225, 2012, 'Professional/Career Problem', 5),
(226, 2012, 'Family Problems', 1320),
(227, 2012, 'Illegitimate Pregnancy', 5),
(228, 2012, 'Dowry Dispute', 139),
(229, 2012, 'Insanity/Mental Illness', 164),
(230, 2012, 'Bankruptcy or Sudden change in Economic', 6),
(231, 2012, 'Unemployment', 16),
(232, 2012, 'Causes Not known', 76),
(233, 2012, 'Fall in Social Reputation', 9),
(234, 2012, 'Property Dispute', 0),
(235, 2012, 'Drug Abuse/Addiction', 1),
(236, 2012, 'Death of Dear Person', 27),
(237, 2012, 'Cancer', 2),
(238, 2012, 'Paralysis', 1),
(239, 2012, 'Cancellation/Non-Settlement of Marriage', 53),
(240, 2012, 'Illness (Aids/STD)', 4),
(241, 2012, 'Other Causes (Please Specity)', 74),
(242, 2012, 'Not having Children(Barrenness/Impotency', 39),
(243, 2012, 'Other Causes (Please Specity)', 164),
(244, 2012, 'Dowry Dispute', 2),
(245, 2012, 'Failure in Examination', 148),
(246, 2012, 'Love Affairs', 145),
(247, 2012, 'Unemployment', 130),
(248, 2012, 'Suspected/Illicit Relation', 15),
(249, 2012, 'Illegitimate Pregnancy', 0),
(250, 2012, 'Not having Children(Barrenness/Impotency', 6),
(251, 2012, 'Illness (Aids/STD)', 9),
(252, 2012, 'Bankruptcy or Sudden change in Economic', 77),
(253, 2012, 'Ideological Causes/Hero Worshipping', 0),
(254, 2012, 'Property Dispute', 9),
(255, 2012, 'Family Problems', 1362),
(256, 2012, 'Other Prolonged Illness', 367),
(257, 2012, 'Divorce', 5),
(258, 2012, 'Paralysis', 5),
(259, 2012, 'Poverty', 51),
(260, 2012, 'Cancer', 4),
(261, 2012, 'Physical Abuse (Rape/Incest Etc.)', 0),
(262, 2012, 'Death of Dear Person', 27),
(263, 2012, 'Insanity/Mental Illness', 218),
(264, 2012, 'Cancellation/Non-Settlement of Marriage', 61),
(265, 2012, 'Causes Not known', 179),
(266, 2012, 'Drug Abuse/Addiction', 439),
(267, 2012, 'Professional/Career Problem', 62),
(268, 2012, 'Fall in Social Reputation', 11),
(269, 2012, 'By Jumping from (Building)', 25),
(270, 2012, 'By Over Alcoholism', 1),
(271, 2012, 'By Overdose of sleeping pills', 11),
(272, 2012, 'By Other means (please specify)', 7),
(273, 2012, 'By Jumping off Moving Vehicles/Trains', 5),
(274, 2012, 'By coming under running vehicles/trains', 7),
(275, 2012, 'By Drowning', 233),
(276, 2012, 'By Machine', 1),
(277, 2012, 'By Hanging', 1030),
(278, 2012, 'By Jumping from (Other sites)', 1),
(279, 2012, 'By Fire/Self Immolation', 492),
(280, 2012, 'By Consuming Insecticides', 528),
(281, 2012, 'By Consuming Other Poison', 181),
(282, 2012, 'By Self Infliction of injury', 9),
(283, 2012, 'By Fire-Arms', 0),
(284, 2012, 'By touching electric wires', 0),
(285, 2012, 'By Jumping from (Other sites)', 12),
(286, 2012, 'By Fire-Arms', 0),
(287, 2012, 'By Other means (please specify)', 6),
(288, 2012, 'By coming under running vehicles/trains', 33),
(289, 2012, 'By Consuming Other Poison', 204),
(290, 2012, 'By Fire/Self Immolation', 191),
(291, 2012, 'By Jumping off Moving Vehicles/Trains', 19),
(292, 2012, 'By Hanging', 1900),
(293, 2012, 'By Self Infliction of injury', 7),
(294, 2012, 'By Machine', 3),
(295, 2012, 'By Over Alcoholism', 49),
(296, 2012, 'By Overdose of sleeping pills', 4),
(297, 2012, 'By touching electric wires', 2),
(298, 2012, 'By Consuming Insecticides', 817),
(299, 2012, 'By Drowning', 222),
(300, 2012, 'By Jumping from (Building)', 27),
(301, 2012, 'Public Sector Undertaking', 8),
(302, 2012, 'Farming/Agriculture Activity', 100),
(303, 2012, 'Others (Please Specify)', 111),
(304, 2012, 'Self-employed (Business activity)', 2),
(305, 2012, 'Service (Private)', 108),
(306, 2012, 'Unemployed', 91),
(307, 2012, 'Professional Activity', 13),
(308, 2012, 'Retired Person', 0),
(309, 2012, 'Service (Government)', 19),
(310, 2012, 'Others (Please Specify)', 41),
(311, 2012, 'House Wife', 1637),
(312, 2012, 'Student', 401),
(313, 2012, 'Others (Please Specify)', 246),
(314, 2012, 'Public Sector Undertaking', 60),
(315, 2012, 'Retired Person', 0),
(316, 2012, 'Student', 376),
(317, 2012, 'Service (Government)', 32),
(318, 2012, 'House Wife', 0),
(319, 2012, 'Others (Please Specify)', 607),
(320, 2012, 'Self-employed (Business activity)', 164),
(321, 2012, 'Service (Private)', 721),
(322, 2012, 'Professional Activity', 116),
(323, 2012, 'Farming/Agriculture Activity', 804),
(324, 2012, 'Unemployed', 370);

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `ques_id` int(20) NOT NULL,
  `ques_text` text NOT NULL,
  `ques_cat_id` int(20) NOT NULL,
  `ques_sub_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`ques_id`, `ques_text`, `ques_cat_id`, `ques_sub_date`) VALUES
(1, 'Have you ever felt like you don\'t have any genuine friends?', 1, '0000-00-00 00:00:00'),
(2, 'Have you ever felt like your friends don\'t really care about you?', 1, '0000-00-00 00:00:00'),
(3, 'Have you ever felt like your friends use you for their own benefit?', 1, '0000-00-00 00:00:00'),
(4, 'Have you ever felt excluded or left out by your friends?', 1, '0000-00-00 00:00:00'),
(5, 'Have you ever experienced betrayal or deceit from a friend?', 1, '0000-00-00 00:00:00'),
(6, 'Have you ever felt like your friends don\'t really understand you?', 1, '0000-00-00 00:00:00'),
(7, 'Have you ever been bullied or harassed by your friends?', 1, '0000-00-00 00:00:00'),
(8, 'Have you ever felt that your friendship is one sided?', 1, '0000-00-00 00:00:00'),
(9, 'Did you ever felt alone being wit your friends?', 1, '0000-00-00 00:00:00'),
(10, 'Have you ever feel replacable being as a true friend too?', 1, '0000-00-00 00:00:00'),
(11, 'How often do you feel that you lack companionship?', 2, '0000-00-00 00:00:00'),
(12, 'How often do you feel that there is no one you can turn to?', 2, '0000-00-00 00:00:00'),
(13, 'How often do you feel isolated from your partner?', 2, '0000-00-00 00:00:00'),
(14, 'How often do you feel that you are not good for your partner?', 2, '0000-00-00 00:00:00'),
(15, 'How often do you feel that you dont have a special one who care about you?', 2, '0000-00-00 00:00:00'),
(16, 'How often do you feel that you dont have a sense of belonging?', 2, '0000-00-00 00:00:00'),
(17, 'How often do you feel that you  dont have a sense of belonging?', 2, '0000-00-00 00:00:00'),
(18, 'How often you feel that u dont have partner to share life problems?', 2, '0000-00-00 00:00:00'),
(19, 'how much u feel that u dont have a special one at home waititng for u?', 2, '0000-00-00 00:00:00'),
(20, 'How often do you feel left out?', 2, '0000-00-00 00:00:00'),
(21, 'How often u feel that u dont have moeny?', 3, '0000-00-00 00:00:00'),
(22, 'How many days you feel that your friends are richer than you?', 3, '0000-00-00 00:00:00'),
(23, 'how often you feel that you dont have a future without money?', 3, '0000-00-00 00:00:00'),
(24, ' have you ever felt that money is more important than life?', 3, '0000-00-00 00:00:00'),
(25, 'Have you ever felt that you will not survive without money?', 3, '0000-00-00 00:00:00'),
(26, 'Do you ever feel bankrupt??', 3, '0000-00-00 00:00:00'),
(27, 'Do you feel that death is better than loans?', 3, '0000-00-00 00:00:00'),
(28, 'Do you feel suicide is end of money problems?', 3, '0000-00-00 00:00:00'),
(29, 'Do you feel money is like air you cant survive without it?', 3, '0000-00-00 00:00:00'),
(30, 'Is being rich  matter to ou any time?', 3, '0000-00-00 00:00:00'),
(31, 'Do you feel doing hard studies too cant make you win?', 4, '0000-00-00 00:00:00'),
(32, 'Have you ever felt like you don\'t have any mentor to motivate you for your studies?', 4, '0000-00-00 00:00:00'),
(33, 'Have you ever felt like your academic performance is negatively impacting your mental health or well-being?', 4, '0000-00-00 00:00:00'),
(34, 'Have you ever felt like you are constantly competing with your peers to achieve the highest grades?', 4, '0000-00-00 00:00:00'),
(35, 'Have you ever experienced academic failure or received grades that were significantly lower than you expected?', 4, '0000-00-00 00:00:00'),
(36, 'Have you ever experienced significant stress or anxiety related to your academic performance or results?', 4, '0000-00-00 00:00:00'),
(37, 'Have you ever felt like your academic performance is the only thing that matters to your family or peers?', 4, '0000-00-00 00:00:00'),
(38, 'Have you ever felt like you are not smart enough to succeed academically?', 4, '0000-00-00 00:00:00'),
(39, 'Have you ever felt like your academic performance defines your worth as a person?', 4, '0000-00-00 00:00:00'),
(40, 'Have you ever felt overwhelming pressure to perform academically?', 4, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `question_category`
--

CREATE TABLE `question_category` (
  `ques_cat_id` int(20) NOT NULL,
  `ques_cat_title` varchar(20) NOT NULL,
  `ques_cat_dt_create` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `question_category`
--

INSERT INTO `question_category` (`ques_cat_id`, `ques_cat_title`, `ques_cat_dt_create`) VALUES
(1, 'friendship', '2023-03-11 22:24:15'),
(2, 'relationship', '2023-03-11 22:24:15'),
(3, 'money', '2023-03-11 22:26:58'),
(4, 'education', '2023-03-11 22:26:58');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `reg_date` datetime NOT NULL DEFAULT current_timestamp(),
  `role` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `reg_date`, `role`) VALUES
(10, 'madi', 'madi@gmail.com', '$2y$10$9htgtTK/fI3n.JMhn.wtv.oh6Uw1kZptEu2QAth06mqGQfSb1ahv6', '2023-03-10 20:25:13', 1),
(11, 'asaa', 'asaa123@gmail.com', '$2y$10$phKQLqkzb2jYAqQjjXthJeXVB.XpIhrAojPNMlbChlQG/itqeP./.', '2023-04-13 14:22:14', 0),
(13, 'aaqib', 'aaqib123@gmail.com', '$2y$10$IsxH/QgrM6vqI3RRe/8lm.D9On0sHi9l3vSEJqFM1nQ3PUTWrqZVm', '2023-04-13 14:27:55', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_response`
--

CREATE TABLE `user_response` (
  `response_id` int(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `formName` varchar(50) NOT NULL,
  `predict_percent` int(20) NOT NULL,
  `response_sub_dt` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_response`
--

INSERT INTO `user_response` (`response_id`, `username`, `formName`, `predict_percent`, `response_sub_dt`) VALUES
(11, 'asaa', 'friendship', 33, '2023-04-13 14:26:48'),
(12, 'asaa', 'educattion', 98, '2023-04-13 14:27:09'),
(13, 'aaqib', 'friendship', 39, '2023-04-13 14:29:10'),
(14, 'madi', 'friendship', 34, '2023-04-13 15:08:48'),
(15, 'madi', 'friendship', 95, '2023-04-13 15:09:21'),
(16, 'madi', 'educattion', 100, '2023-04-13 15:10:45'),
(17, 'asaa', 'friendship', 100, '2023-04-13 15:14:48'),
(18, 'madi', 'friendship', 17, '2023-04-13 15:17:02'),
(19, 'madi', 'friendship', 96, '2023-04-13 15:17:23');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `olddata`
--
ALTER TABLE `olddata`
  ADD PRIMARY KEY (`oldData_id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`ques_id`);

--
-- Indexes for table `question_category`
--
ALTER TABLE `question_category`
  ADD PRIMARY KEY (`ques_cat_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_response`
--
ALTER TABLE `user_response`
  ADD PRIMARY KEY (`response_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `olddata`
--
ALTER TABLE `olddata`
  MODIFY `oldData_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=325;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `ques_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `question_category`
--
ALTER TABLE `question_category`
  MODIFY `ques_cat_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `user_response`
--
ALTER TABLE `user_response`
  MODIFY `response_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
